from os import supports_bytes_environ
from django.db import models

# Create your models here.

class student(models.Model):
    
    sname=models.CharField(max_length=50, default='') 
    semail=models.CharField(max_length=50, default='')
    smob=models.CharField(max_length=12, default='')
    swp=models.CharField(max_length=12, default='')
    sadd=models.CharField(max_length=100, default='')
    scity=models.CharField(max_length=50, default='')
    scourse=models.CharField(max_length=50, default='')
    sbranch=models.CharField(max_length=50, default='')
    stsess=models.CharField(max_length=50, default='')
    ensess=models.CharField(max_length=50, default='')
    sdes=models.CharField(max_length=500, default='')
    