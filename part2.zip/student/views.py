from college.models import student
from django.shortcuts import render

def index(request):
        return render(request,'student/index.html')

def stprofile(request):
    try:
        email=request.GET['email'];
        psw=request.GET['psw'];
        a=student.objects.get(semail=email,spass=psw)
        print(a)
        return render(request,'student/stprofile.html')
    except:
        print('hello..') 
        return render(request,'student/index.html')

    