from django.http import HttpResponse
from django.shortcuts import render,HttpResponseRedirect
from college.models import college,student


def index(request):
    return render(request,"index.html")
def contact(request):
    return render(request,"contact.html")
def about(request):
    return render(request,"about.html")

def collegelogin(request):
        return render(request,"collegelogin.html")
def collegereg(request):
    try:
        cnm=request.POST['cnm']
        unm=request.POST['unm']
        cemail=request.POST['cemail']
        cmob=request.POST['cmob']
        cadd=request.POST['cadd']
        ccity=request.POST['ccity']
        cweb=request.POST['cweb']
        cdes=request.POST['cdes']
        cimg=request.POST['cimg']
        cstatus=request.POST['cstatus']
        cpwd=request.POST['cpwd']
        if cmob == "":
            return render(request,"collegereg.html")
        else:

            print(cnm)
            r=college(cname=cnm,uname=unm,cemail=cemail,cmob=cmob,cadd=cadd,ccity=ccity,cweb=cweb,cdes=cdes,cimg=cimg,cstatus=cstatus,cpwd=cpwd)
            r.save()
            #params={'val': 'record inserted'}
            return render(request,"collegereg.html")#,params)
    except:
        print("Hello...")
        return render (request,"collegereg.html")


def collegeshow(request):
    col=college.objects.all()
    params={'coldata':col}
    #return render(request,'college/index.html',params)
    return render(request,"collegeshow.html",params)


def collegeprofile(request):
    cnm=request.GET['cnm']
    data=college.objects.get(cname=cnm)
    
    if request.method == 'POST' :
        data.delete()
        return HttpResponseRedirect('/')
    
    return render(request,'collegeprofile.html',{'cl':data})  


def base(request):
    return render(request,'base.html')

def edit(request):
    return render (request,"edit.html")


def search(request):
    cnm=request.GET['cnm']
    data=college.objects.filter(title__icontains=cnm)
    params={'data':data}
    return render(request,'search.html',params)
   