from django.db import models
from django.db.models.base import ModelState
from django.db.models.deletion import CASCADE
from django.contrib.auth.hashers import make_password


class college(models.Model):
    cid=models.AutoField
    cname=models.CharField(max_length=50,default='')
    uname=models.CharField(max_length=50,default='')
    cemail=models.CharField(max_length=50,default='')
    cmob=models.CharField(max_length=12,default='')
    cadd=models.CharField(max_length=100,default='')
    ccity=models.CharField(max_length=50,default='')
    cweb=models.CharField(max_length=50,default='')
    cdes=models.CharField(max_length=500,default='')
    cimg=models.ImageField(upload_to="media/college/",default='')
    cstatus=models.CharField(max_length=50,default='no')
    cpwd=models.CharField(max_length=20,default='') 

def __str__(self):
        return self.cname
    

class student(models.Model):
    cid=models.ForeignKey(college,on_delete=models.CASCADE,default='')
    sid=models.AutoField
    sname=models.CharField(max_length=50, default='') 
    sgender=models.CharField(max_length=10,default='')
    semail=models.CharField(max_length=50, default='')
    smob=models.CharField(max_length=12, default='')
    swp=models.CharField(max_length=12, default='')
    sadd=models.CharField(max_length=100, default='')
    scity=models.CharField(max_length=50, default='')
    scourse=models.CharField(max_length=50, default='')
    sbranch=models.CharField(max_length=50, default='')
    stsess=models.CharField(max_length=50, default='')
    ensess=models.CharField(max_length=50, default='')
    sdes=models.CharField(max_length=500, default='')
    sstatus=models.CharField(max_length=50,default='no')
    spass=models.CharField(max_length=20,default='')
     
    def __str__(self):
        return self.sname
    
