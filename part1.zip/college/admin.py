from django.contrib import admin
from . models import college, student

admin.site.register(college)
admin.site.register(student)
# Register your models here.
