
from django.shortcuts import render
from college.models import college
from college.models import student


def index(request):
    try:
        email=request.POST['email'];
        psw=request.POST['psw'];
        data=college.objects.get(cemail=email,cpwd=psw);
        print(data)
        return render(request,'college/index.html')
    except:
        print('hello')
        return render(request,"collegelogin.html")
def studentreg(request):
    a=college.objects.all()
    try:
        snm=request.POST['snm']
        if snm == "":
            return render(request,'college/studentreg.html',{"st":a})
        else:
            print(snm)
            a=student(sname=snm,)
            a.save()
            return render(request,'college/studentreg.html',{"st":a})
    except:
        print('hiii....')
        return render(request,'college/studentreg.html',{"st":a})

def studentshow(request):
    st=student.objects.all()
    params={'stdata':st}
    return render(request,'college/studentshow.html',params)  
# Create your views here.
